
const DEFAULT_STATIONS=[
 {id:'BCT',name:'Mumbai Central',code:'MMCT',platforms:[1,2,3,4,5],wheelchairCount:10,availableWheelchairs:8,staffCount:12,availableStaff:5,vehicleCount:4,availableVehicles:3,facilities:['Ramps','Lifts','Tactile paths','Accessible toilets']},
 {id:'CSMT',name:'Mumbai CSMT',code:'CSMT',platforms:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18],wheelchairCount:12,availableWheelchairs:7,staffCount:15,availableStaff:6,vehicleCount:4,availableVehicles:2,facilities:['Ramps','Lifts','Wheelchair assistance','Accessible toilets']},
 {id:'DR',name:'Dadar',code:'DR',platforms:[1,2,3,4,5,6,7,8],wheelchairCount:8,availableWheelchairs:5,staffCount:10,availableStaff:4,vehicleCount:3,availableVehicles:2,facilities:['Ramps','Lifts','Tactile paths']},
 {id:'TNA',name:'Thane',code:'TNA',platforms:[1,2,3,4,5,6,7,8],wheelchairCount:8,availableWheelchairs:6,staffCount:10,availableStaff:4,vehicleCount:3,availableVehicles:2,facilities:['Ramps','Lifts','Accessible toilets']},
 {id:'PUNE',name:'Pune Junction',code:'PUNE',platforms:[1,2,3,4,5,6],wheelchairCount:10,availableWheelchairs:7,staffCount:12,availableStaff:8,vehicleCount:4,availableVehicles:3,facilities:['Ramps','Lifts','Tactile paths','Accessible toilets']},
 {id:'SVJR',name:'Shivajinagar',code:'SVJR',platforms:[1,2,3,4],wheelchairCount:6,availableWheelchairs:4,staffCount:8,availableStaff:4,vehicleCount:2,availableVehicles:1,facilities:['Ramps','Lift','Accessible toilets']},
 {id:'LNL',name:'Lonavala',code:'LNL',platforms:[1,2,3],wheelchairCount:5,availableWheelchairs:3,staffCount:6,availableStaff:3,vehicleCount:2,availableVehicles:1,facilities:['Ramps','Wheelchair assistance']},
 {id:'NK',name:'Nashik Road',code:'NK',platforms:[1,2,3,4,5,6],wheelchairCount:7,availableWheelchairs:4,staffCount:8,availableStaff:3,vehicleCount:2,availableVehicles:1,facilities:['Ramps','Lifts','Accessible toilets']},
 {id:'NGP',name:'Nagpur',code:'NGP',platforms:[1,2,3,4,5,6,7,8],wheelchairCount:10,availableWheelchairs:6,staffCount:12,availableStaff:6,vehicleCount:4,availableVehicles:2,facilities:['Ramps','Lifts','Tactile paths','Accessible toilets']},
 {id:'ADI',name:'Ahmedabad',code:'ADI',platforms:[1,2,3,4,5,6,7,8,9,10,11,12],wheelchairCount:11,availableWheelchairs:7,staffCount:14,availableStaff:7,vehicleCount:4,availableVehicles:3,facilities:['Ramps','Lifts','Accessible toilets']},
 {id:'NDLS',name:'New Delhi',code:'NDLS',platforms:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],wheelchairCount:15,availableWheelchairs:10,staffCount:20,availableStaff:10,vehicleCount:6,availableVehicles:4,facilities:['Ramps','Lifts','Tactile paths','Accessible toilets']},
 {id:'MAS',name:'Chennai Central',code:'MAS',platforms:[1,2,3,4,5,6,7,8,9,10,11,12],wheelchairCount:12,availableWheelchairs:8,staffCount:15,availableStaff:7,vehicleCount:5,availableVehicles:3,facilities:['Ramps','Lifts','Accessible toilets']},
 {id:'SBC',name:'Bengaluru City',code:'SBC',platforms:[1,2,3,4,5,6,7,8],wheelchairCount:10,availableWheelchairs:5,staffCount:13,availableStaff:6,vehicleCount:4,availableVehicles:2,facilities:['Ramps','Lifts','Tactile paths']},
 {id:'HWH',name:'Howrah',code:'HWH',platforms:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],wheelchairCount:18,availableWheelchairs:12,staffCount:24,availableStaff:12,vehicleCount:7,availableVehicles:5,facilities:['Ramps','Lifts','Tactile paths','Accessible toilets']}
];
function loadStationCatalog(){
  try {
    const saved=JSON.parse(localStorage.getItem(DB_KEYS.stations)||'null');
    if(Array.isArray(saved)&&saved.length) return saved;
  } catch(e){}
  localStorage.setItem(DB_KEYS.stations, JSON.stringify(DEFAULT_STATIONS));
  return DEFAULT_STATIONS;
}
let STATIONS=loadStationCatalog();
function refreshStations(){STATIONS=loadStationCatalog();return STATIONS}
const stationData=()=>STATIONS;
const findStation=(q)=>STATIONS.find(s=>s.name===q||s.code===q||s.id===q);
const stationOptions=(selected='')=>STATIONS.map(s=>`<option value="${s.name}" ${s.name===selected?'selected':''}>${s.name} — ${s.code}</option>`).join('');
function searchableStationSelect(id,name='station',selected=''){return `<div class="station-picker"><input id="${id}_search" class="station-search" placeholder="Search station name or code" autocomplete="off"><select id="${id}" name="${name}" required>${stationOptions(selected)}</select><div id="${id}_recent" class="small muted"></div></div>`}
function overlaps(a,b){if(!a||!b||a.date!==b.date)return false;let at=a.time||'00:00',bt=b.time||'00:00';return Math.abs((new Date(`2000-01-01T${at}`)-new Date(`2000-01-01T${bt}`))/60000)<60}
function resourceFree(resourceId,type,booking){if(!resourceId)return true;return !read(DB_KEYS.bookings).some(b=>b.bookingId!==booking.bookingId&&b[type]===resourceId&&!['Completed','Cancelled'].includes(b.status)&&overlaps(b,booking))}
function capabilityMatch(resource,requirement=''){let r=(requirement||'').toLowerCase(),skills=(resource.skills||[]).join(' ').toLowerCase();if(!r)return 0;if(r.includes('wheelchair')&&skills.includes('wheelchair'))return 20;if((r.includes('visual')||r.includes('blind'))&&skills.includes('visual'))return 20;if((r.includes('hearing')||r.includes('deaf'))&&skills.includes('hearing'))return 20;return 0}
function calculateAssignmentScore(resource,booking,type){
 let score=25;
 if(resource.station===booking.station)score+=30;
 if(String(resource.currentPlatform||'')===String(booking.platform||''))score+=20;
 if(resourceFree(resource.id,type,booking))score+=15;
 const active=read(DB_KEYS.bookings).filter(b=>(b.staffId===resource.id||b.wheelchairId===resource.id||b.vehicleId===resource.id)&&!['Completed','Cancelled'].includes(b.status)).length;
 score+=Math.max(0,10-active*5);
 score+=capabilityMatch(resource,booking.accessibility);
 return Math.min(100,score);
}
function findBestWheelchair(booking){return read(DB_KEYS.wheelchairs).filter(x=>x.status==='Available'&&resourceFree(x.id,'wheelchairId',booking)).map(x=>({...x,score:calculateAssignmentScore(x,booking,'wheelchairId')})).sort((a,b)=>b.score-a.score)[0]||null}
function findBestStaff(booking){return read(DB_KEYS.staff).filter(x=>x.status==='Available'&&resourceFree(x.id,'staffId',booking)).map(x=>({...x,score:calculateAssignmentScore(x,booking,'staffId')})).sort((a,b)=>b.score-a.score)[0]||null}
function findBestVehicle(booking){return read(DB_KEYS.vehicles).filter(x=>x.status==='Available'&&resourceFree(x.id,'vehicleId',booking)).map(x=>({...x,score:calculateAssignmentScore(x,booking,'vehicleId')})).sort((a,b)=>b.score-a.score)[0]||null}
function assignmentReason(staff,booking){if(!staff)return 'No suitable staff/resource is currently available.';let reasons=[];if(staff.station===booking.station)reasons.push(`available at ${booking.station}`);if(String(staff.currentPlatform||'')===String(booking.platform||''))reasons.push(`near Platform ${booking.platform}`);if(resourceFree(staff.id,'staffId',booking))reasons.push('no overlapping assignment');if(capabilityMatch(staff,booking.accessibility))reasons.push('qualified for the requested assistance');return `Staff ${staff.id} was selected because they are ${reasons.join(', ')}.`}
function priorityRank(p){return p==='Emergency'?3:p==='High'?2:1}
function autoAssignResources(booking){
 let needStaff=!['Wheelchair'].includes(booking.service)||booking.staffRequired==='yes'||booking.priority==='Emergency';
 let needVehicle=booking.service==='Vehicle'||booking.vehicleRequired==='yes';
 let wc=booking.service==='Wheelchair'?findBestWheelchair(booking):null;
 let staff=needStaff?findBestStaff(booking):null;
 let vehicle=needVehicle?findBestVehicle(booking):null;
 if(booking.service==='Wheelchair'&&!wc)return {mode:'MANUAL',reason:'No suitable wheelchair is currently available.'};
 if(needStaff&&!staff)return {mode:'MANUAL',reason:'A suitable staff/porter is not currently available.'};
 if(needVehicle&&!vehicle)return {mode:'REVIEW',reason:'Vehicle is unavailable; authority review is recommended.',wheelchair:wc,staff};
 let score=Math.round(((wc?.score||0)+(staff?.score||0)+(vehicle?.score||0))/[wc,staff,vehicle].filter(Boolean).length);
 let mode=(booking.priority==='Emergency'||score>=70)?'AUTO':'REVIEW';
 return {mode,score,wheelchair:wc,staff,vehicle,reason:assignmentReason(staff,booking)};
}
function applyAutoAssignment(booking){
 let r=autoAssignResources(booking);
 let patch={assignmentType:r.mode==='AUTO'?'AUTO':r.mode==='REVIEW'?'REVIEW':'MANUAL',assignmentScore:r.score||0,assignmentStatus:r.mode==='AUTO'?'AUTO_ASSIGNED':r.mode==='REVIEW'?'AWAITING_REVIEW':'MANUAL_ASSIGNMENT_REQUIRED',assignmentReason:r.reason};
 if(r.wheelchair)Object.assign(patch,{wheelchairId:r.wheelchair.id});
 if(r.staff)Object.assign(patch,{staffId:r.staff.id,staffName:r.staff.name});
 if(r.vehicle)Object.assign(patch,{vehicleId:r.vehicle.id});
 patch.status=r.mode==='AUTO'?'Assigned':r.mode==='REVIEW'?'Assignment Pending':'Manual Assignment Required';
 let b=updateBooking(booking.bookingId,patch);
 if(r.mode==='AUTO'){
  let w=read(DB_KEYS.wheelchairs),s=read(DB_KEYS.staff),v=read(DB_KEYS.vehicles);
  if(r.wheelchair){let x=w.find(q=>q.id===r.wheelchair.id);if(x)x.status='Assigned'} if(r.staff){let x=s.find(q=>q.id===r.staff.id);if(x){x.status='Assigned';x.assignment=booking.bookingId}} if(r.vehicle){let x=v.find(q=>q.id===r.vehicle.id);if(x)x.status='Assigned'}
  write(DB_KEYS.wheelchairs,w);write(DB_KEYS.staff,s);write(DB_KEYS.vehicles,v);
  addNotification(b.passengerId,'Auto Assignment Successful',`Your request ${b.bookingId} has been automatically assigned.`);
  addNotification('AUTH001','New Auto Assignment',`Request ${b.bookingId} was automatically assigned to ${b.staffName||'available resources'}.`);
  if(b.staffId)addNotification(b.staffId,'New Assistance Request',`Request ${b.bookingId} has been assigned to you.`);
 }
 return b;
}
