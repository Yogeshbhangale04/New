function serviceAvailability(station){
  const a = read(DB_KEYS.availability, {});
  const s = findStation(station);
  if (a[station]) return {
    wheelchair: Math.max(0, Number(a[station].wheelchair) || 0),
    staff: Math.max(0, Number(a[station].staff) || 0),
    vehicle: Math.max(0, Number(a[station].vehicle) || 0)
  };
  return s ? {
    wheelchair: Number(s.availableWheelchairs) || 0,
    staff: Number(s.availableStaff) || 0,
    vehicle: Number(s.availableVehicles) || 0
  } : {wheelchair:0,staff:0,vehicle:0};
}
function renderAvailability(station){
  const a=serviceAvailability(station),wrap=document.getElementById('availabilityCards');
  if(!wrap)return;
  const item=(name,val)=>`<div class="avail"><span>${name}</span><strong>${Number(val)||0}</strong><span class="${val>3?'badge badge-success':val>0?'badge badge-warning':'badge badge-danger'}">${val>3?'Available':val>0?'Limited':'Unavailable'}</span></div>`;
  wrap.innerHTML=item('♿ Wheelchair',a.wheelchair)+item('🧑‍🦽 Staff / Porter',a.staff)+item('🚐 Vehicle',a.vehicle);
}
function renderMyBookings(){
  let u=requireRole('Passenger');if(!u)return;
  let all=read(DB_KEYS.bookings).filter(b=>b.passengerId===u.id),q=document.getElementById('search')?.value.toLowerCase()||'',filter=document.getElementById('filter')?.value||'All';
  let arr=all.filter(b=>(filter==='All'||(filter==='Active'?!['Completed','Cancelled'].includes(b.status):filter===b.status))&&[b.bookingId,b.station,b.service].join(' ').toLowerCase().includes(q));
  let tbody=document.getElementById('bookingRows');if(!tbody)return;
  if(!arr.length){tbody.innerHTML='<tr><td colspan="9" class="empty">No bookings found.</td></tr>';return}
  tbody.innerHTML=arr.map(b=>`<tr><td>${escapeHTML(b.bookingId)}</td><td>${escapeHTML(b.service)}</td><td>${escapeHTML(b.station)}</td><td>${escapeHTML(b.date)}</td><td>${escapeHTML(b.time)}</td><td>${escapeHTML(b.staffName||'Pending')}</td><td>${escapeHTML(b.vehicleId||'—')}</td><td>${statusBadge(b.status)}</td><td><a class="btn btn-sm btn-secondary" href="track-booking.html?id=${encodeURIComponent(b.bookingId)}">Track</a></td></tr>`).join('');
}