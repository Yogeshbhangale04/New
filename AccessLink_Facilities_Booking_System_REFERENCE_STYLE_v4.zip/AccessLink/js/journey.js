function validateJourneyData(data){
  const errors=[];
  if(!/^\d{8,12}$/.test(data.pnr||'')) errors.push('PNR must contain 8–12 digits.');
  if(!/^\d{4,5}$/.test(data.trainNumber||'')) errors.push('Train number must contain 4–5 digits.');
  if(!data.date) errors.push('Travel date is required.');
  else {const d=new Date(data.date+'T00:00:00');const t=new Date();t.setHours(0,0,0,0);if(d<t)errors.push('Travel date cannot be in the past.');}
  if(!findStation(data.from)) errors.push('Please select a valid boarding station.');
  if(!findStation(data.to)) errors.push('Please select a valid destination station.');
  if(data.from && data.to && data.from===data.to) errors.push('Boarding and destination stations must be different.');
  return errors;
}
function saveJourney(data){sessionStorage.setItem('al_journey',JSON.stringify({...data,savedAt:new Date().toISOString()}));}
function getJourney(){try{return JSON.parse(sessionStorage.getItem('al_journey')||'null')}catch(e){return null}}
