
const DB_KEYS={users:'al_users',session:'al_session',bookings:'al_bookings',staff:'al_staff',wheelchairs:'al_wheelchairs',vehicles:'al_vehicles',availability:'al_availability',feedback:'al_feedback',notifications:'al_notifications',prefs:'al_prefs',stations:'al_stations',eco:'al_eco_submissions',rewards:'al_rewards'};
function read(key, fallback=[]){try{return JSON.parse(localStorage.getItem(key))??fallback}catch(e){return fallback}}
function write(key,value){localStorage.setItem(key,JSON.stringify(value))}
function uid(prefix){return prefix+Math.random().toString(36).slice(2,8).toUpperCase()+Date.now().toString().slice(-4)}
function toast(msg,type='info'){let t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),3000)}
function escapeHTML(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function seedData(force=false){
 if(force){ Object.values(DB_KEYS).forEach(k=>localStorage.removeItem(k)); localStorage.removeItem('al_seeded'); }
 if(localStorage.getItem('al_seeded') && !force) return;
 write(DB_KEYS.users,[
  {id:'USR001',name:'Demo Passenger',email:'passenger@accesslink.com',password:'Passenger@123',role:'Passenger',age:'34',emergency:'9876543210',accessibility:'Wheelchair assistance'},
  {id:'AUTH001',name:'Demo Authority',email:'authority@accesslink.com',password:'Authority@123',role:'Railway Authority'},
  {id:'ST-021',name:'Ravi Kumar',email:'staff@accesslink.com',password:'Staff@123',role:'Staff / Porter',station:'Mumbai Central',status:'Available'},
  {id:'ST-022',name:'Anita Shah',email:'anita@accesslink.com',password:'Staff@123',role:'Staff / Porter',station:'Pune Junction',status:'Available'},
  {id:'ST-023',name:'Imran Khan',email:'imran@accesslink.com',password:'Staff@123',role:'Staff / Porter',station:'Mumbai Central',status:'On Break'}
 ]);
 write(DB_KEYS.staff,[
  {id:'ST-001',name:'Ravi Kumar',station:'Mumbai Central',currentPlatform:'4',status:'Available',skills:['Wheelchair','Visual'],assignment:null},
  {id:'ST-002',name:'Anita Shah',station:'Pune Junction',currentPlatform:'4',status:'Available',skills:['Wheelchair','Hearing'],assignment:null},
  {id:'ST-003',name:'Imran Khan',station:'Mumbai Central',currentPlatform:'2',status:'On Break',skills:['Luggage'],assignment:null},
  {id:'ST-004',name:'Meera Joshi',station:'Pune Junction',currentPlatform:'2',status:'Available',skills:['Wheelchair','Visual'],assignment:null},
  {id:'ST-005',name:'Arjun Patil',station:'New Delhi',currentPlatform:'6',status:'Available',skills:['Wheelchair','Hearing'],assignment:null},
  {id:'ST-006',name:'Neha Singh',station:'Mumbai CSMT',currentPlatform:'10',status:'Available',skills:['Visual','Luggage'],assignment:null}
]);
write(DB_KEYS.wheelchairs,[
  {id:'WC-001',station:'Mumbai Central',status:'Available',type:'Standard',currentPlatform:'4'},
  {id:'WC-002',station:'Mumbai Central',status:'Available',type:'Standard',currentPlatform:'2'},
  {id:'WC-003',station:'Pune Junction',status:'Available',type:'Standard',currentPlatform:'4'},
  {id:'WC-004',station:'Pune Junction',status:'Available',type:'Motorized',currentPlatform:'2'},
  {id:'WC-005',station:'Mumbai CSMT',status:'Available',type:'Standard',currentPlatform:'10'},
  {id:'WC-006',station:'New Delhi',status:'Available',type:'Standard',currentPlatform:'6'},
  {id:'WC-007',station:'Mumbai Central',status:'Maintenance',type:'Motorized',currentPlatform:'1'},
  {id:'WC-008',station:'Pune Junction',status:'Available',type:'Standard',currentPlatform:'1'}
]);
write(DB_KEYS.vehicles,[
  {id:'EV-001',type:'Electric Buggy',station:'Mumbai Central',capacity:4,status:'Available'},
  {id:'EV-002',type:'Accessibility Vehicle',station:'Pune Junction',capacity:4,status:'Available'},
  {id:'EV-003',type:'Station Shuttle',station:'Mumbai Central',capacity:8,status:'Available'},
  {id:'EV-004',type:'Electric Buggy',station:'New Delhi',capacity:4,status:'Available'},
  {id:'EV-005',type:'Accessibility Vehicle',station:'Mumbai CSMT',capacity:4,status:'Maintenance'}
]);

 
 write(DB_KEYS.availability,{'Mumbai Central':{wheelchair:8,staff:5,vehicle:3},'Mumbai CSMT':{wheelchair:7,staff:6,vehicle:2},'Dadar':{wheelchair:5,staff:4,vehicle:2},'Thane':{wheelchair:6,staff:4,vehicle:2},'Pune Junction':{wheelchair:7,staff:8,vehicle:3},'Shivajinagar':{wheelchair:4,staff:4,vehicle:1},'Lonavala':{wheelchair:3,staff:3,vehicle:1},'Nashik Road':{wheelchair:4,staff:3,vehicle:1},'Nagpur':{wheelchair:6,staff:6,vehicle:2},'Ahmedabad':{wheelchair:7,staff:7,vehicle:3},'New Delhi':{wheelchair:10,staff:10,vehicle:4},'Chennai Central':{wheelchair:8,staff:7,vehicle:3},'Bengaluru City':{wheelchair:5,staff:6,vehicle:2},'Howrah':{wheelchair:12,staff:12,vehicle:5}});
 write(DB_KEYS.bookings,[
 {bookingId:'AL-10001',passengerId:'USR001',passengerName:'Demo Passenger',email:'passenger@accesslink.com',mobile:'9876543210',service:'Wheelchair',station:'Pune Junction',date:'2026-09-04',time:'09:30',platform:'4',pnr:'10000001',trainNumber:'12127',trainName:'Intercity Express',passengers:1,accessibility:'Wheelchair assistance',special:'Completed demo booking',emergency:'9876543210',status:'Completed',staffId:'ST-002',staffName:'Anita Shah',wheelchairId:'WC-003',vehicleId:'',assignmentType:'AUTO',assignmentScore:92,assignmentStatus:'AUTO_ASSIGNED',assignmentReason:'Station and platform matched.',priority:'Normal',createdAt:new Date().toISOString()},
 {bookingId:'AL-10002',passengerId:'USR001',passengerName:'Demo Passenger',email:'passenger@accesslink.com',mobile:'9876543210',service:'Staff / Porter Assistance',station:'Mumbai Central',date:'2026-09-07',time:'11:00',platform:'4',pnr:'10000002',trainNumber:'12951',trainName:'Mumbai Rajdhani',passengers:1,accessibility:'Luggage assistance',special:'In progress demo booking',emergency:'9876543210',status:'In Progress',staffId:'ST-001',staffName:'Ravi Kumar',wheelchairId:'',vehicleId:'',assignmentType:'AUTO',assignmentScore:88,assignmentStatus:'AUTO_ASSIGNED',assignmentReason:'Available at Mumbai Central near Platform 4.',priority:'Normal',createdAt:new Date().toISOString()},
 {bookingId:'AL-10003',passengerId:'USR001',passengerName:'Demo Passenger',email:'passenger@accesslink.com',mobile:'9876543210',service:'Wheelchair',station:'Pune Junction',date:'2026-09-08',time:'14:30',platform:'2',pnr:'10000003',trainNumber:'11010',trainName:'Sinhagad Express',passengers:1,accessibility:'Wheelchair assistance',special:'Assigned demo booking',emergency:'9876543210',status:'Staff Assigned',staffId:'ST-004',staffName:'Meera Joshi',wheelchairId:'WC-004',vehicleId:'',assignmentType:'AUTO',assignmentScore:95,assignmentStatus:'AUTO_ASSIGNED',assignmentReason:'Staff is available at Pune Junction near Platform 2 and has wheelchair skills.',priority:'Normal',createdAt:new Date().toISOString()},
 {bookingId:'AL-10004',passengerId:'USR001',passengerName:'Demo Passenger',email:'passenger@accesslink.com',mobile:'9876543210',service:'Vehicle',station:'Mumbai CSMT',date:'2026-09-10',time:'16:00',platform:'10',pnr:'10000004',trainNumber:'12220',trainName:'Duronto Express',passengers:2,accessibility:'Mobility support',special:'Awaiting request processing',emergency:'9876543210',status:'Requested',staffId:'',staffName:'',wheelchairId:'',vehicleId:'',assignmentType:'',assignmentScore:0,assignmentStatus:'',assignmentReason:'',priority:'Normal',createdAt:new Date().toISOString()},
 {bookingId:'AL-10005',passengerId:'USR001',passengerName:'Demo Passenger',email:'passenger@accesslink.com',mobile:'9876543210',service:'Wheelchair',station:'Pune Junction',date:'2026-09-09',time:'18:00',platform:'6',pnr:'10000005',trainNumber:'11030',trainName:'Koyna Express',passengers:1,accessibility:'Special accessibility requirement',special:'Manual review demo',emergency:'9876543210',status:'Manual Assignment Required',staffId:'',staffName:'',wheelchairId:'',vehicleId:'',assignmentType:'MANUAL',assignmentScore:0,assignmentStatus:'MANUAL_ASSIGNMENT_REQUIRED',assignmentReason:'No suitable wheelchair/staff/vehicle is currently available.',priority:'High',createdAt:new Date().toISOString()}
]);
 write(DB_KEYS.feedback,[]);
 write(DB_KEYS.eco,[]);
 write(DB_KEYS.rewards,{USR001:{points:250,history:[]}});
 write(DB_KEYS.notifications,[{id:uid('N'),userId:'USR001',title:'Staff Assigned',message:'Ravi Kumar has been assigned to AL-2026-10482.',time:new Date().toISOString(),read:false}]);
 localStorage.setItem('al_seeded','1');
}
function currentUser(){let s=read(DB_KEYS.session,null);return s}
function requireRole(role){let u=currentUser();if(!u){location.href='../login.html';return null}if(role && u.role!==role){toast('Access denied. Redirecting...','error');setTimeout(()=>location.href=role==='Passenger'?'../passenger/dashboard.html':role==='Railway Authority'?'../authority/dashboard.html':'../staff/dashboard.html',700);return null}return u}
function saveBooking(b){let arr=read(DB_KEYS.bookings);arr.push(b);write(DB_KEYS.bookings,arr)}
function updateBooking(id,patch){let arr=read(DB_KEYS.bookings);arr=arr.map(b=>b.bookingId===id?{...b,...patch}:b);write(DB_KEYS.bookings,arr);return arr.find(b=>b.bookingId===id)}
function addNotification(userId,title,message){let n=read(DB_KEYS.notifications);n.unshift({id:uid('N'),userId,title,message,time:new Date().toISOString(),read:false});write(DB_KEYS.notifications,n)}
function applyPrefs(){let p=read(DB_KEYS.prefs,{});document.body.classList.toggle('high-contrast',!!p.highContrast);document.body.classList.toggle('large-text',!!p.largeText)}
function initApp(){seedData();applyPrefs()}
document.addEventListener('DOMContentLoaded',initApp);
