
function authUser(){return requireRole('Railway Authority')}
function el(id){return document.getElementById(id)}
function setText(id,value){let x=el(id);if(x)x.textContent=value}

function renderAuthority(){
  let u=authUser(); if(!u)return;
  let bs=read(DB_KEYS.bookings),a=read(DB_KEYS.availability,{}),staff=read(DB_KEYS.staff),veh=read(DB_KEYS.vehicles),wc=read(DB_KEYS.wheelchairs);

  setText('today',bs.length);
  setText('pending',bs.filter(b=>['Requested','Availability Checked','Assignment Pending','Manual Assignment Required'].includes(b.status)).length);
  setText('wca',wc.filter(x=>x.status==='Available').length);
  setText('sta',staff.filter(x=>x.status==='Available').length);
  setText('veha',veh.filter(x=>x.status==='Available').length);

  let rows=el('requestRows');
  if(rows) rows.innerHTML=bs.map(b=>`<tr><td>${escapeHTML(b.bookingId)}</td><td>${escapeHTML(b.passengerName)}</td><td>${escapeHTML(b.service)}</td><td>${escapeHTML(b.station)}</td><td>${escapeHTML(b.date)}</td><td>${escapeHTML(b.time)}</td><td>${statusBadge(b.status)}</td><td>${escapeHTML(b.assignmentType||'Pending')}</td><td><button class="btn btn-sm btn-primary" onclick="openAssign('${b.bookingId}')">Assign</button></td></tr>`).join('');

  let av=el('availabilityRows');
  if(av) av.innerHTML=Object.entries(a).map(([s,x])=>`<tr><td>${escapeHTML(s)}</td><td><input data-st="${escapeHTML(s)}" data-k="wheelchair" value="${Number(x.wheelchair)||0}" type="number" min="0"></td><td><input data-st="${escapeHTML(s)}" data-k="staff" value="${Number(x.staff)||0}" type="number" min="0"></td><td><input data-st="${escapeHTML(s)}" data-k="vehicle" value="${Number(x.vehicle)||0}" type="number" min="0"></td><td><button class="btn btn-sm btn-success" onclick="saveAvailability('${String(s).replace(/'/g,"\\'")}')">Save</button></td></tr>`).join('');

  let staffRows=el('staffRows');
  if(staffRows) staffRows.innerHTML=staff.length?staff.map(x=>`<tr><td>${escapeHTML(x.id)}</td><td>${escapeHTML(x.name)}</td><td>${escapeHTML(x.station)}</td><td>${escapeHTML((x.skills||[]).join(', ')||'—')}</td><td>${statusBadge(x.status)}</td><td>${escapeHTML(x.assignment||'—')}</td><td><button class="btn btn-sm btn-secondary" onclick="editStaff('${x.id}')">Edit</button> <button class="btn btn-sm btn-danger" onclick="deleteResource('staff','${x.id}')">Delete</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty">No staff resources.</td></tr>';

  let vehRows=el('vehicleRows');
  if(vehRows) vehRows.innerHTML=veh.length?veh.map(x=>`<tr><td>${escapeHTML(x.id)}</td><td>${escapeHTML(x.type)}</td><td>${escapeHTML(x.station)}</td><td>${escapeHTML(x.capacity)}</td><td>${statusBadge(x.status)}</td><td><button class="btn btn-sm btn-secondary" onclick="editVehicle('${x.id}')">Edit</button> <button class="btn btn-sm btn-danger" onclick="deleteResource('vehicles','${x.id}')">Delete</button></td></tr>`).join(''):'<tr><td colspan="6" class="empty">No vehicles.</td></tr>';

  let wcRows=el('wcRows');
  if(wcRows) wcRows.innerHTML=wc.length?wc.map(x=>`<tr><td>${escapeHTML(x.id)}</td><td>${escapeHTML(x.type||'Standard')}</td><td>${escapeHTML(x.station)}</td><td>${escapeHTML(x.currentPlatform||'—')}</td><td>${statusBadge(x.status)}</td><td><button class="btn btn-sm btn-secondary" onclick="editWheelchair('${x.id}')">Edit</button> <button class="btn btn-sm btn-danger" onclick="deleteResource('wheelchairs','${x.id}')">Delete</button></td></tr>`).join(''):'<tr><td colspan="6" class="empty">No wheelchairs.</td></tr>';
}

function saveAvailability(st){
  let a=read(DB_KEYS.availability,{}), els=[...document.querySelectorAll(`[data-st="${CSS.escape(st)}"]`)].reduce((o,e)=>(o[e.dataset.k]=Math.max(0,Number(e.value)||0),o),{});
  a[st]=els; write(DB_KEYS.availability,a); renderAuthority(); toast('Station availability updated by Railway Authority.');
}

function resourceModal(title,body,onSave){
  let m=el('resourceModal'); if(!m){m=document.createElement('div');m.id='resourceModal';m.className='modal';document.body.appendChild(m)}
  m.classList.remove('hidden'); m.innerHTML=`<div class="modal-box"><h2>${escapeHTML(title)}</h2>${body}<div class="actions"><button id="resourceSave" class="btn btn-primary">Save</button><button class="btn btn-secondary" onclick="closeResourceModal()">Cancel</button></div></div>`;
  el('resourceSave').onclick=onSave;
}
function closeResourceModal(){el('resourceModal')?.classList.add('hidden')}
function stationChoices(selected=''){return (typeof STATIONS!=='undefined'?STATIONS:[]).map(s=>`<option ${s.name===selected?'selected':''}>${escapeHTML(s.name)}</option>`).join('')}

function addWheelchair(){editWheelchair('')}
function editWheelchair(id){
  let arr=read(DB_KEYS.wheelchairs),x=arr.find(q=>q.id===id)||{id:'',type:'Standard',station:'Pune Junction',currentPlatform:'1',status:'Available'};
  resourceModal(id?'Edit Wheelchair':'Add Wheelchair',`<div class="form-grid">
    <div class="field"><label>Wheelchair ID *</label><input id="rId" value="${escapeHTML(x.id)}" ${id?'readonly':''}></div>
    <div class="field"><label>Type *</label><select id="rType"><option ${x.type==='Standard'?'selected':''}>Standard</option><option ${x.type==='Motorized'?'selected':''}>Motorized</option></select></div>
    <div class="field"><label>Station *</label><select id="rStation">${stationChoices(x.station)}</select></div>
    <div class="field"><label>Platform *</label><input id="rPlatform" value="${escapeHTML(x.currentPlatform||'1')}"></div>
    <div class="field"><label>Status *</label><select id="rStatus">${['Available','Assigned','Maintenance'].map(v=>`<option ${x.status===v?'selected':''}>${v}</option>`).join('')}</select></div>
  </div>`,()=>saveResource('wheelchairs',id,{id:el('rId').value.trim(),type:el('rType').value,station:el('rStation').value,currentPlatform:el('rPlatform').value.trim(),status:el('rStatus').value}));
}

function addStaff(){editStaff('')}
function editStaff(id){
  let arr=read(DB_KEYS.staff),x=arr.find(q=>q.id===id)||{id:'',name:'',station:'Pune Junction',currentPlatform:'1',status:'Available',skills:['Wheelchair'],assignment:null};
  resourceModal(id?'Edit Staff / Porter':'Add Staff / Porter',`<div class="form-grid">
    <div class="field"><label>Staff ID *</label><input id="rId" value="${escapeHTML(x.id)}" ${id?'readonly':''}></div>
    <div class="field"><label>Name *</label><input id="rName" value="${escapeHTML(x.name)}"></div>
    <div class="field"><label>Station *</label><select id="rStation">${stationChoices(x.station)}</select></div>
    <div class="field"><label>Current Platform *</label><input id="rPlatform" value="${escapeHTML(x.currentPlatform||'1')}"></div>
    <div class="field full"><label>Skills (comma separated) *</label><input id="rSkills" value="${escapeHTML((x.skills||[]).join(', '))}" placeholder="Wheelchair, Visual, Hearing, Luggage"></div>
    <div class="field"><label>Status *</label><select id="rStatus">${['Available','Assigned','On Break'].map(v=>`<option ${x.status===v?'selected':''}>${v}</option>`).join('')}</select></div>
  </div>`,()=>saveResource('staff',id,{id:el('rId').value.trim(),name:el('rName').value.trim(),station:el('rStation').value,currentPlatform:el('rPlatform').value.trim(),skills:el('rSkills').value.split(',').map(s=>s.trim()).filter(Boolean),status:el('rStatus').value,assignment:x.assignment||null}));
}

function addVehicle(){editVehicle('')}
function editVehicle(id){
  let arr=read(DB_KEYS.vehicles),x=arr.find(q=>q.id===id)||{id:'',type:'Electric Buggy',station:'Pune Junction',capacity:4,status:'Available'};
  resourceModal(id?'Edit Vehicle':'Add Vehicle',`<div class="form-grid">
    <div class="field"><label>Vehicle ID *</label><input id="rId" value="${escapeHTML(x.id)}" ${id?'readonly':''}></div>
    <div class="field"><label>Type *</label><input id="rType" value="${escapeHTML(x.type)}"></div>
    <div class="field"><label>Station *</label><select id="rStation">${stationChoices(x.station)}</select></div>
    <div class="field"><label>Capacity *</label><input id="rCapacity" type="number" min="1" value="${escapeHTML(x.capacity)}"></div>
    <div class="field"><label>Status *</label><select id="rStatus">${['Available','Assigned','Maintenance'].map(v=>`<option ${x.status===v?'selected':''}>${v}</option>`).join('')}</select></div>
  </div>`,()=>saveResource('vehicles',id,{id:el('rId').value.trim(),type:el('rType').value.trim(),station:el('rStation').value,capacity:Math.max(1,Number(el('rCapacity').value)||1),status:el('rStatus').value}));
}

function saveResource(key,oldId,obj){
  if(!obj.id || (key==='staff'&&!obj.name) || (key==='vehicles'&&!obj.type)){toast('Please complete all mandatory resource fields.');return}
  let storageKey=DB_KEYS[key],arr=read(storageKey);
  if(!oldId && arr.some(x=>x.id.toLowerCase()===obj.id.toLowerCase())){toast('Resource ID already exists.');return}
  if(oldId) arr=arr.map(x=>x.id===oldId?{...x,...obj}:x); else arr.push(obj);
  write(storageKey,arr); syncAvailabilityFromResources(); closeResourceModal(); renderAuthority(); toast(oldId?'Resource updated.':'Resource added.');
}
function deleteResource(key,id){
  if(!confirm(`Delete ${id}? This cannot be undone.`))return;
  let storageKey=DB_KEYS[key],arr=read(storageKey);
  let inUse=read(DB_KEYS.bookings).some(b=>!['Completed','Cancelled'].includes(b.status)&&(b.staffId===id||b.wheelchairId===id||b.vehicleId===id));
  if(inUse){toast('Cannot delete a resource that is assigned to an active booking.');return}
  write(storageKey,arr.filter(x=>x.id!==id)); syncAvailabilityFromResources(); renderAuthority(); toast('Resource deleted.');
}
function syncAvailabilityFromResources(){
  let a=read(DB_KEYS.availability,{});
  let stations=typeof STATIONS!=='undefined'?STATIONS.map(s=>s.name):Object.keys(a);
  stations.forEach(st=>{
    a[st]=a[st]||{wheelchair:0,staff:0,vehicle:0};
    a[st].wheelchair=read(DB_KEYS.wheelchairs).filter(x=>x.station===st&&x.status==='Available').length;
    a[st].staff=read(DB_KEYS.staff).filter(x=>x.station===st&&x.status==='Available').length;
    a[st].vehicle=read(DB_KEYS.vehicles).filter(x=>x.station===st&&x.status==='Available').length;
  });
  write(DB_KEYS.availability,a);
}

function openAssign(id){
  let b=read(DB_KEYS.bookings).find(x=>x.bookingId===id); if(!b)return;
  let staff=read(DB_KEYS.staff).filter(x=>x.status==='Available'&&x.station===b.station),
      wc=read(DB_KEYS.wheelchairs).filter(x=>x.status==='Available'&&x.station===b.station),
      veh=read(DB_KEYS.vehicles).filter(x=>x.status==='Available'&&x.station===b.station);
  let m=el('assignModal'); if(!m){m=document.createElement('div');m.id='assignModal';m.className='modal';document.body.appendChild(m)}
  m.classList.remove('hidden');
  m.innerHTML=`<div class="modal-box"><h2>Assign / Override ${escapeHTML(b.bookingId)}</h2><p>${escapeHTML(b.passengerName)} · ${escapeHTML(b.service)} · ${escapeHTML(b.station)}</p>
  <div class='notice'><b>Current Assignment:</b> ${escapeHTML(b.wheelchairId||'—')} · ${escapeHTML(b.staffName||'—')} · ${escapeHTML(b.vehicleId||'—')}<br><b>Why selected:</b> ${escapeHTML(b.assignmentReason||'Not assigned yet')}</div>
  <div class="form-grid"><div class="field"><label>Staff / Porter</label><select id="asStaff"><option value="">No staff</option>${staff.map(x=>`<option value="${x.id}">${escapeHTML(x.name)} (${escapeHTML(x.station)})</option>`).join('')}</select></div>
  <div class="field"><label>Wheelchair</label><select id="asWc"><option value="">No wheelchair</option>${wc.map(x=>`<option value="${x.id}">${escapeHTML(x.id)}</option>`).join('')}</select></div>
  <div class="field full"><label>Vehicle</label><select id="asVeh"><option value="">No vehicle</option>${veh.map(x=>`<option value="${x.id}">${escapeHTML(x.id)} — ${escapeHTML(x.type)}</option>`).join('')}</select></div></div>
  <div class="actions"><button class="btn btn-primary" onclick="confirmAssign('${id}')">Confirm Assignment</button><button class="btn btn-secondary" onclick="closeModal()">Cancel</button></div></div>`;
}
function closeModal(){el('assignModal')?.classList.add('hidden')}
function confirmAssign(id){
  let b=read(DB_KEYS.bookings).find(x=>x.bookingId===id),sid=el('asStaff').value,wid=el('asWc').value,vid=el('asVeh').value,
      st=read(DB_KEYS.staff),wcs=read(DB_KEYS.wheelchairs),vs=read(DB_KEYS.vehicles),s=st.find(x=>x.id===sid);
  if(s){s.status='Assigned';s.assignment=id} let w=wcs.find(x=>x.id===wid);if(w)w.status='Assigned';let v=vs.find(x=>x.id===vid);if(v)v.status='Assigned';
  write(DB_KEYS.staff,st);write(DB_KEYS.wheelchairs,wcs);write(DB_KEYS.vehicles,vs);syncAvailabilityFromResources();
  b=updateBooking(id,{status:sid?'Staff Assigned':'Assigned',staffId:sid,staffName:s?.name||'',wheelchairId:wid,vehicleId:vid,assignmentType:'MANUAL_OVERRIDE',assignmentStatus:'MANUAL_OVERRIDE',assignmentReason:'Assignment manually approved or overridden by Railway Authority.'});
  addNotification(b.passengerId,'Assignment Updated',`Your request ${id} has been assigned${s?.name?' to '+s.name:''}.`);
  toast('Assignment saved.');closeModal();renderAuthority();
}

function stationAdminModal(title,body,onSave){
  resourceModal(title,body,onSave);
}
function addStation(){editStation('')}
function editStation(id){
  refreshStations();
  let x=STATIONS.find(s=>s.id===id)||{id:'',name:'',code:'',platforms:[1,2],wheelchairCount:0,availableWheelchairs:0,staffCount:0,availableStaff:0,vehicleCount:0,availableVehicles:0,facilities:['Ramps','Accessible toilets']};
  stationAdminModal(id?'Edit Station':'Add Station',`<div class="form-grid">
    <div class="field"><label>Station ID *</label><input id="stId" value="${escapeHTML(x.id)}" ${id?'readonly':''}></div>
    <div class="field"><label>Station Code *</label><input id="stCode" value="${escapeHTML(x.code)}" maxlength="8"></div>
    <div class="field full"><label>Station Name *</label><input id="stName" value="${escapeHTML(x.name)}"></div>
    <div class="field full"><label>Platforms *</label><input id="stPlatforms" value="${escapeHTML((x.platforms||[]).join(', '))}" placeholder="1, 2, 3, 4"></div>
    <div class="field full"><label>Accessibility Facilities *</label><input id="stFacilities" value="${escapeHTML((x.facilities||[]).join(', '))}" placeholder="Ramps, Lifts, Accessible toilets"></div>
  </div>`,()=>saveStation(id));
}
function saveStation(oldId){
  let id=el('stId').value.trim().toUpperCase(),code=el('stCode').value.trim().toUpperCase(),name=el('stName').value.trim();
  let platforms=el('stPlatforms').value.split(',').map(x=>Number(x.trim())).filter(Number.isInteger).filter(x=>x>0);
  let facilities=el('stFacilities').value.split(',').map(x=>x.trim()).filter(Boolean);
  if(!id||!code||!name||!platforms.length||!facilities.length){toast('Complete all mandatory station fields.');return}
  let arr=read(DB_KEYS.stations,STATIONS);
  if(!oldId && arr.some(x=>x.id.toUpperCase()===id||x.code.toUpperCase()===code)){toast('Station ID or code already exists.');return}
  let old=arr.find(x=>x.id===oldId);
  let obj={id,name,code,platforms,facilities,wheelchairCount:old?.wheelchairCount||0,availableWheelchairs:old?.availableWheelchairs||0,staffCount:old?.staffCount||0,availableStaff:old?.availableStaff||0,vehicleCount:old?.vehicleCount||0,availableVehicles:old?.availableVehicles||0};
  if(oldId)arr=arr.map(x=>x.id===oldId?{...x,...obj}:x);else arr.push(obj);
  write(DB_KEYS.stations,arr);refreshStations();
  let av=read(DB_KEYS.availability,{});if(!av[name])av[name]={wheelchair:0,staff:0,vehicle:0};write(DB_KEYS.availability,av);
  closeResourceModal();renderAuthority();renderStationAdmin();toast(oldId?'Station updated.':'Station added.');
}
function deleteStation(id){
  refreshStations();let s=STATIONS.find(x=>x.id===id);if(!s)return;
  let inUse=read(DB_KEYS.bookings).some(b=>!['Completed','Cancelled'].includes(b.status)&&b.station===s.name);
  let resources=[...read(DB_KEYS.staff),...read(DB_KEYS.wheelchairs),...read(DB_KEYS.vehicles)].some(x=>x.station===s.name);
  if(inUse||resources){toast('Cannot delete a station used by an active booking or resource.');return}
  if(!confirm(`Delete ${s.name}?`))return;
  let arr=read(DB_KEYS.stations,[]).filter(x=>x.id!==id);write(DB_KEYS.stations,arr);let av=read(DB_KEYS.availability,{});delete av[s.name];write(DB_KEYS.availability,av);refreshStations();renderAuthority();renderStationAdmin();toast('Station deleted.');
}
function renderStationAdmin(){
  let box=el('stationRows');if(!box)return;refreshStations();
  box.innerHTML=STATIONS.map(s=>`<tr><td>${escapeHTML(s.code)}</td><td>${escapeHTML(s.name)}</td><td>${escapeHTML((s.facilities||[]).join(', '))}</td><td>${(s.platforms||[]).length}</td><td>${Number(read(DB_KEYS.availability, {})[s.name]?.wheelchair)||0} WC / ${Number(read(DB_KEYS.availability,{})[s.name]?.staff)||0} Staff / ${Number(read(DB_KEYS.availability,{})[s.name]?.vehicle)||0} Vehicles</td><td><button class="btn btn-sm btn-secondary" onclick="editStation('${escapeHTML(s.id)}')">Edit</button> <button class="btn btn-sm btn-danger" onclick="deleteStation('${escapeHTML(s.id)}')">Delete</button></td></tr>`).join('');
}
