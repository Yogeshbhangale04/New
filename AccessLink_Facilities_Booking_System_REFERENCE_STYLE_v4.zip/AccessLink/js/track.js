function renderTrack(){
 let u=requireRole('Passenger');if(!u)return;
 let id=new URLSearchParams(location.search).get('id')||'',b=read(DB_KEYS.bookings).find(x=>x.bookingId===id&&x.passengerId===u.id),box=document.getElementById('trackBox');
 if(!b){box.innerHTML='<div class="empty">Invalid booking ID.</div>';return}
 const normal=['Requested','Availability Checked','Assignment Processing','Assignment Pending','Assigned','Staff Assigned','In Progress','Completed'];
 const stages=b.status==='Manual Assignment Required'?['Requested','Availability Checked','Assignment Processing','Manual Assignment Required']:normal;
 let current=Math.max(0,stages.indexOf(b.status));
 box.innerHTML=`<div class="notice"><b>Current Status:</b> ${statusBadge(b.status)}<br><span class="small">Assignment: ${escapeHTML(b.assignmentType||'Pending')} · ${escapeHTML(b.assignmentReason||'')}</span></div><div class="timeline">${stages.map((s,i)=>`<div class="step ${i<current?'done':''} ${i===current?'current':''}"><div class="dot">${i<current?'✓':i+1}</div><div><div class="title">${s}</div><div class="small muted">${i<=current?'Completed / current stage':'Pending'}</div></div></div>`).join('')}</div><hr><div class="grid3"><div><b>Assigned Staff</b><br>${escapeHTML(b.staffName||'Pending')}</div><div><b>Facility</b><br>${escapeHTML(b.wheelchairId||b.service)}</div><div><b>Vehicle</b><br>${escapeHTML(b.vehicleId||'—')}</div><div><b>Station</b><br>${escapeHTML(b.station)}</div><div><b>Platform</b><br>${escapeHTML(b.platform||'—')}</div><div><b>Expected Time</b><br>${escapeHTML(b.date||'')} ${escapeHTML(b.time||'')}</div></div>`
}
function lookupTrack(e){e.preventDefault();let id=document.getElementById('trackId').value.trim();location.href='track-booking.html?id='+encodeURIComponent(id)}
