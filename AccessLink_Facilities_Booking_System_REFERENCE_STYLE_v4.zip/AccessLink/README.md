# AccessLink Facilities Booking System

## Extended prototype
This version preserves the original AccessLink workflow and adds:
- Smart Auto / Review / Manual assignment modes
- Rule-based resource scoring
- Station/platform/time/workload/capability matching
- Emergency/High/Normal priority
- Conflict prevention for staff, wheelchairs and vehicles
- Transparent assignment reason
- Authority override
- Mobile OTP verification with expiry, resend and attempt limits
- Strong password validation and live strength indicator
- Searchable 14-station dataset with station codes, platforms and facilities
- Expanded dummy staff, wheelchair and vehicle inventory
- Five test bookings across multiple states
- Review-before-request gate
- Duplicate-submission protection
- Demo data load/reset controls

## Run
Open `index.html` in a modern browser. No backend or build process is required.

## Demo accounts
Passenger: passenger@accesslink.com / Passenger@123
Railway Authority: authority@accesslink.com / Authority@123
Staff / Porter: staff@accesslink.com / Staff@123

## Demo OTP
Registration generates a six-digit OTP in the UI. It is deliberately simulated; no SMS is sent.

## Important
Frontend authentication is simulated using localStorage and is not suitable for production authentication.


## Fixes in current build
- Book Facility now shows all dummy assistance stations directly in the station dropdown and supports name/code search.
- Check Availability and Review Booking use visible validation and Review remains disabled until availability is checked.
- Mobile/emergency contacts require exactly 10 digits; invalid email is blocked.
- Railway Authority can add/edit/delete wheelchairs, staff/porters, and vehicles. Resource availability is synchronized with admin changes.


## v3 fixes / UX improvements
- Fixed passenger Availability Check and Review Booking flow with explicit element references.
- Availability Check now validates only the details needed to calculate availability; full mandatory validation happens before Review/Request.
- Mobile validation is strict: exactly 10 digits and Indian mobile numbers must start with 6–9.
- Email validation is stricter and rejects malformed domains, missing TLDs, consecutive dots and invalid local parts.
- All 14 dummy assistance stations are now visibly listed as clickable station chips in Book Facility.
- Railway Authority has a clear Admin Control Center and can add/edit/delete wheelchairs, staff/porters and vehicles, plus manage station availability and manual assignment overrides.
- Browser cache-busting query strings were added to updated pages/scripts so old frontend files are less likely to remain cached.
